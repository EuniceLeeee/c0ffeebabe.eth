import type { DiscoverySemantics } from "../../adapter-family-plugin.js";
import { explicitReverseBindingUnsupported } from
  "../../adapter-family-plugin.js";
import {
  canonicalAddress,
  lowerAddress,
} from "../standard-family/common.js";
import { PSM_INTERFACE } from "./codec.js";
import type { PsmCandidate } from "./types.js";
import { createAddressSurfaceNomination } from "../../address-surface-nomination.js";

export const psmDiscovery = {
  evidenceChannel: "nominate" as const,
  sources: ["observed-call", "address-surface"],
  callPatterns: ["sellGem", "buyGem"].map((fn) => ({
    id: `psm-${fn.toLowerCase()}-call`,
    selector: PSM_INTERFACE.getFunction(fn)!.selector as `0x${string}`,
    signature: `${fn}(address,uint256)`,
    candidateAddress: { from: "call-target" as const },
  })),
  addressSurfaces: [{
    id: "psm-lite-surface",
    kind: "interface",
    fingerprint: "lite-psm-gem-dai-fees-v1",
  }],
  decodeCandidate({ observation, matchedPatternId }) {
    if (
      observation.kind === "call" &&
      (matchedPatternId === "psm-sellgem-call" ||
        matchedPatternId === "psm-buygem-call")
    ) {
      return Object.freeze({
        candidateKind: "lite-psm" as const,
        target: canonicalAddress(observation.target),
      });
    }
    if (
      observation.kind === "address-surface" &&
      matchedPatternId === "psm-lite-surface"
    ) {
      return Object.freeze({
        candidateKind: "lite-psm" as const,
        target: canonicalAddress(observation.address),
      });
    }
    return null;
  },
  candidateKey: (candidate) => lowerAddress(candidate.target),
  nominate: createAddressSurfaceNomination({
    opaqueLabels: Object.freeze(["psm", "protocol:psm"]),
    interfaceFingerprints: Object.freeze(["lite-psm-gem-dai-fees-v1"]),
  }),
  reverseBinding: explicitReverseBindingUnsupported(
    "no reverse-binding registry declared (explicit unsupported)",
  ),
} satisfies DiscoverySemantics<PsmCandidate>;